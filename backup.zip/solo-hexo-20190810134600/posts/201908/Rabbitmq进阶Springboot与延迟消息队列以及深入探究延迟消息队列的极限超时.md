title: Rabbitmq - 进阶：Springboot 与延迟消息队列，以及深入探究延迟消息队列的极限超时
date: '2019-08-07 16:48:16'
updated: '2019-08-07 16:49:07'
tags: [rabbitmq, mq延迟队列]
permalink: /articles/2019/08/07/1565167696743.html
---
![](https://img.hacpai.com/bing/20180829.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


# Rabbitmq - 进阶：延迟消息队列，以及深入探究延迟消息队列的极限超时
----


代码 github地址 ：https://github.com/FrankZuozuo/rabbitmq-max-timeout

#### 1、构建一个简单的springboot 应用

pom

```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.6.RELEASE</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.wretchant</groupId>
    <artifactId>rabbitmq-max-timeout</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>rabbitmq-max-timeout</name>
    <description>测试rabbitmq 死信队列的最大超时时间</description>

    <properties>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-amqp</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <dependency>
            <groupId>com.google.guava</groupId>
            <artifactId>guava</artifactId>
            <version>26.0-jre</version>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-configuration-processor</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>

</project>

```



配置文件

```

spring:
  rabbitmq:
    virtual-host: docker-mq-vhost
    username: root
    password: root

```

#### 3、构建rabbitmq 环境
通过docker 构建一个简单的rabbitmq 环境，创建一台虚拟机

参考： Docker - 创建并运行rabbitmq镜像 https://blog.csdn.net/qq_15071263/article/details/94883165

#### 2、编写一个非延迟队列

```
    @Bean("a")
    DirectExchange directExchange(){
        return new DirectExchange("a");
    }

    @Bean("t")
    Queue queue(){
        return new Queue("t");
    }


    @Bean
    Binding binding(Queue t,DirectExchange a){
        return BindingBuilder.bind(t).to(a).with("t");
    }


    @RabbitListener(queues = "t")
    public void confirm(String msg){
        log.info("收到消息 ： {} ",msg);
    }
```

#### 3、测试非延迟队列是否能够正常工作

```

    @Autowired
    private AmqpTemplate amqpTemplate;

amqpTemplate.convertAndSend("a","t","消息");

```

mq 可以正常工作


```
2019-07-24 14:22:04.956  INFO 9352 --- [ntContainer#1-1] c.w.r.config.QueueListener               : 收到消息 ： 消息 
```

#### 4、了解延迟队列以及延迟队列的注意事项

参考：通过RabbitMQ 死信队列实现延迟MQ消息，消息延迟，MQ延迟队列
https://blog.csdn.net/qq_15071263/article/details/89636161


#### 5、创建延迟队列配置

```
    @Bean("prod")
    DirectExchange prod() {
        return new DirectExchange("prod");
    }

    @Bean("consu")
    DirectExchange consu() {
        return new DirectExchange("consu");
    }

    @Bean("prodQ")
    Queue prodQ() {
        Map<String, Object> args = Maps.newHashMap();
        args.put("x-dead-letter-exchange", "consu");
        args.put("x-dead-letter-routing-key", "consuQ");
        args.put("x-message-ttl", 5000);

        return new Queue("prodQ", true, false, false, args);
    }

    @Bean("consuQ")
    Queue consuQ() {
        return new Queue("consuQ");
    }

    @Bean
    Binding send(Queue prodQ, DirectExchange prod) {
        return BindingBuilder.bind(prodQ).to(prod).with("prodQ");
    }

    @Bean
    Binding receive(Queue consuQ, DirectExchange consu) {
        return BindingBuilder.bind(consuQ).to(consu).with("consuQ");
    }

    @RabbitListener(queues = "consuQ")
    public void exec(String msg) {
        log.info("我的延迟队列，接收时间为 {} ， 消息 {}", DateTimeFormatter.ofPattern("HH:mm:ss").format(LocalDateTime.now()), msg);
    }
```



#### 6、编写测试代码

```

@Slf4j
@SpringBootApplication
public class RabbitmqMaxTimeoutApplication {

    public static void main(String[] args) {
        SpringApplication.run(RabbitmqMaxTimeoutApplication.class, args);
    }



    @Autowired
    private AmqpTemplate amqpTemplate;
    

    @Bean
    ApplicationRunner applicationRunner(){
        return args -> {
            amqpTemplate.convertAndSend("a","t","消息");
            amqpTemplate.convertAndSend("prod","prodQ","我是消息内容");
        };
    }

}

```

启动应用，可以看到五秒后收到一条消息

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724143725123.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)


#### 7、到rabbitmq 管理面板查看创建的队列，交换机信息

队列信息

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724143937570.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)

交换机信息

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724144010998.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)


我们来看延迟队列的信息，跟我们的设置是一致的

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724144128878.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)

#### 8、创建了延迟队列后是不是就可以为所欲为了呢

深入研究过rabbitmq 延迟消息，或者因为业务存在超长延迟时间的会发现，MQ 的TTL 有一个时间限制
有很多的文章会指出，MQ 支持的最大消息延迟是 4,294,967,295 ，也就是 2的32次方-1，不到50天

#### 9、rabbitmq 的极限延迟探究

实际上，rabbitmq 遵循 AMQP 0-9-1 协议，支持short-short-int，short-int，  long-int或long-long-int 这些类型
所以，消息的最大延迟支持 long long int 的最大值 【0x7fffffffffffffffL】，也就是2的64次方-1，在Java 中，就是

```
Long.MAX_VALUE
```

可以参考rabbitmq 的官方文档 ： https://www.rabbitmq.com/ttl.html

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724145506125.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)
#### 10、创建一个极限延迟的队列

修改延迟为极限值
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724145827563.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190724145813331.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)

如果我们使用一个比 Long.MAX_VALUE 还大 1的数值，则该队列不能被创建

重新启动应用，我们可以看到，有一条等待消费的消息

![在这里插入图片描述](https://img-blog.csdnimg.cn/201907241500196.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly93cmV0Y2hhbnQuYmxvZy5jc2RuLm5ldA==,size_16,color_FFFFFF,t_70)


