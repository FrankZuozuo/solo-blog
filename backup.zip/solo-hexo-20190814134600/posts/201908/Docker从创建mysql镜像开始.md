title: Docker - 从创建mysql镜像开始
date: '2019-08-07 22:20:01'
updated: '2019-08-07 22:20:01'
tags: [docker]
permalink: /articles/2019/08/07/1565187601905.html
---

# Docker - 从创建mysql镜像开始
----



#### 1、下载mysql 镜像

下载mysql 5.7 版本的镜像
```
docker pull mysql:5.7
```
下载完成后如图所示
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234213794.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)


#### 2、查看已经安装的镜像

```
docker image ls
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234318659.png)

#### 3、运行mysql 镜像

```
docker run --name dockermysql -p 3306:3306 -d -e MYSQL_ROOT_PASSWORD=root -d mysql:5.7
```
运行成功后，会输出镜像id
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234445493.png)

#### 4、进入docker 命令行界面

```
docker exec -it dockermysql /bin/bash
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234529516.png)
#### 5、登陆mysql

```
mysql -u root -p
```
然后输入mysql 登陆密码：root
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019070223461730.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)

#### 6、mysql 授权

```
 GRANT ALL PRIVILEGES ON *.* TO 'root'@'%'WITH GRANT OPTION;
```

```
 FLUSH PRIVILEGES;
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234727100.png)

#### 7、退出mysql 面板

```
exit
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234808467.png)

#### 8、退出docker 命令行
```
exit
```
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234837458.png)
#### 9、通过连接工具或者代码连接mysql
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234913803.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)


成功连接
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702234935503.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)
