title: Docker -  Windows10下挂载宿主机文件夹到镜像
date: '2019-08-07 22:21:02'
updated: '2019-08-07 22:21:02'
tags: [docker]
permalink: /articles/2019/08/07/1565187662156.html
---

# Docker -  Windows10下挂载宿主机文件夹到镜像
---


#### 1、docker: Error response from daemon: Mount denied:

第一种情况，使用windows 目录结构

```
docker run -p 6379:6379 -v $PWDC:\docker.image.data\redis\data:/data -d redis:5.0.5 redis-server --appendonly yes
```
运行如上命令，会报错

```
docker: Error response from daemon: Mount denied:
The source path "$PWDC:\\docker.image.data\\redis\\data"
is not a valid Windows path.
See 'docker run --help'.
```

原因是 \ 不能被docker 识别

#### 2、docker: Error response from daemon: invalid mode: /data.

```
docker run -p 6379:6379 -v $PWDC:/docker.image.data/redis/data/:/data -d redis:5.0.5 redis-server --appendonly yes
```
运行如上命令，会报错

```
docker: Error response from daemon: invalid mode: /data.
See 'docker run --help'.
```

原因是即使是windows 下的目录，也必须使用linux 形式的目录结构


#### 3、正确挂载外部目录
```
docker run -p 6379:6379 -v /c/docker.image.data/redis/data:/data -d redis:5.0.5 redis-server --appendonly yes
```

比如你的目录是 

```
C:\docker.image.data\redis\data
```
则需要写成

```
/c/docker.image.data/redis/data
```
