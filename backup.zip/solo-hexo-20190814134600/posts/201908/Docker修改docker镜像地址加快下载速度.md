title: Docker - 修改docker 镜像地址加快下载速度
date: '2019-08-07 22:19:33'
updated: '2019-08-07 22:19:33'
tags: [docker]
permalink: /articles/2019/08/07/1565187573137.html
---

# Docker - 修改docker 镜像地址加快下载速度
---


#### 1、打开控制面板
1、找到 小鲸鱼
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702231954958.png)
2、打开右键菜单，选择 settings

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702232029370.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)

#### 2、修改镜像地址并重启
默认情况下，registry-mirrors 的数组是一个空的，你可以去寻找国内一些公开的镜像地址，然后点击apply，docker 会自动重启，然后即可快速的下载官方镜像

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702232143294.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)
