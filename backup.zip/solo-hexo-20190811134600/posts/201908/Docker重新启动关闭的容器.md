title: Docker - 重新启动关闭的容器
date: '2019-08-07 22:20:30'
updated: '2019-08-07 22:20:30'
tags: [docker]
permalink: /articles/2019/08/07/1565187630024.html
---

# Docker - 重新启动关闭的容器
---

> 如果卸载了 mysql ，然后重新安装，重新配置，重新授权等一系列操作下来，大约需要半个小时到1个小时，但是docker ，只需要1分钟左右。


#### 1、查看所有已经创建的容器

先运行docker 环境，然后执行以下命令

```
docker ps -a
```
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190703000153744.png)


#### 2、通过id 启动容器

```
docker start 019481ef4a66
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190703000218133.png)
