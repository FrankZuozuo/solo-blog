title: Docker - 从下载安装Docker开始
date: '2019-08-07 22:18:49'
updated: '2019-08-07 22:18:49'
tags: [docker]
permalink: /articles/2019/08/07/1565187528972.html
---

# Docker - 从下载安装Docker开始

---

#### 1、docker 官方网站
https://hub.docker.com


#### 2、下载docker
windows 版本下载
https://hub.docker.com/editions/community/docker-ce-desktop-windows

下载docker 需要登陆，否则需要注册账号


登陆后，点击如下按钮下载docker 安装程序
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702220534320.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)


#### 3、安装docker
1、找到下载好的文件：Docker for Windows Installer.exe   双击运行

2、得到如下界面
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702220723472.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)

3、开始安装
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702220935875.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)
4、安装完成，提示需要重启，请先保存好需要工作再点击 Log out 蓝色按钮，否则会直接重启

5、重启完成后，如果你的电脑没有开启Hyper-V 功能，会提醒你需要开启Hyper-V，该操作同样会直接重启你的电脑并自动配置开启Hyper-V 虚拟机功能

6、Docker 会自动注册为开机启动应用，如果不需要开机启动，请关闭该功能

至此，docker 安装完成

#### 4、启动并登陆docker
双击启动    ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702222155938.png)


接着，docker 会提示你已经正在运行

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702222238584.png)

登陆docker，找到小鲸鱼图标
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702222413141.png)
右键选择菜单 sign in，弹出登陆面板，登陆即可


![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702222340118.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)


#### 5、查看docker版本
打开cmd 或者 power shell 面板

输入：

```
docker -v
```
或者

```
docker --version
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190702222630219.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzE1MDcxMjYz,size_16,color_FFFFFF,t_70)
